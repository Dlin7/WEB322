const Sequelize = require('sequelize');
const fs = require('fs');
var sequelize = new Sequelize('d1flmeko6a22v9', 'rrhhrlroevlnsh', '04b5205c7c633812564ac6bd989877f75e1ce909f346a097fe3b917820be245b', {
    host: 'ec2-23-23-192-242.compute-1.amazonaws.com',
    dialect: 'postgres',
    port: 5432,
    dialectOptions: {
    ssl: true
    }
});

var Employee = sequelize.define('Employee', {
    employeeNum: {
        type: Sequelize.INTEGER,
        primaryKey: true, // use "employeeNum" as a primary key
        autoIncrement: true // automatically increment the value
    },
    firstName: Sequelize.STRING,
    last_Name: Sequelize.STRING,
    email: Sequelize.STRING,
    SSN: Sequelize.STRING,
    addressStreet: Sequelize.STRING,
    addressCity: Sequelize.STRING,
    addressState: Sequelize.STRING,
    addressPostal: Sequelize.STRING,
    maritalStatus: Sequelize.STRING,
    isManager: Sequelize.BOOLEAN,
    employeeManagerNum: Sequelize.INTEGER,
    status: Sequelize.STRING,
    department: Sequelize.INTEGER,
    hireDate: Sequelize.STRING
});
var Department = sequelize.define('Department', {
    departmentId: {
        type: Sequelize.INTEGER,
        primaryKey: true, // use "employeeNum" as a primary key
        autoIncrement: true // automatically increment the value
    },
    departmentName: Sequelize.STRING,
});



class DataService {
    initialize() {
        return new Promise((resolve,reject) =>{
            sequelize.sync().then(()=>{
                Employee.findAll({
                    attributes: ['*']
                }).then((results) => {
                    resolve(results);
                }).catch(() => {
                    reject("unable to sync the database");
                });
                Department.findAll({
                    attributes: ['*']
                }).then((results) => {
                    resolve(results);
                }).catch(() => {
                    reject("unable to sync the database");
                });
            });
        })
    }


    getAllEmployees() {
        return new Promise((resolve, reject)=> {
            Employee.findAll().then((results) => {
                resolve(results);
            }).catch(() => {
                reject("no results returned");
            });
        });
    }
    
    getEmployeesByStatus() {
        return new Promise((resolve, reject)=> {
            Employee.findAll({
                where: {
                    status: status,
                }
            }).then((results) => {
                resolve(results);
            }).catch(() => {
                reject("no results returned");
            });
        });
    }

    getEmployeesByDepartment() {
        return new Promise((resolve, reject)=> {
            Employee.findAll({
                where: {
                    department: department,
                }
            }).then((results) => {
                resolve(results);
            }).catch(() => {
                reject("no results returned");
            });
        });
    }

    getEmployeesByManager() {
        return new Promise((resolve, reject)=> {
            Employee.findAll({
                where: {
                    employeeManagerNum: manager,
                }
            }).then((results) => {
                resolve(results);
            }).catch(() => {
                reject("no results returned");
            });
        });
    }

    getEmployeesByNum() {
        return new Promise((resolve, reject)=> {
            Employee.findOne({
                where: {
                    employeeNum: num,
                }
            }).then((results) => {
                resolve(results);
            }).catch(() => {
                reject("no results returned");
            });
        });
    }

    getManagers() {
        return new Promise((resolve, reject) => {
            Employee.findAll({
                where: {
                    isManager: true,
                }
            }).then((results) => {
                resolve(results);
            }).catch(() => {
                reject("no results returned");
            });
        })
    }

    getDepartments() {
        return new Promise((resolve, reject) =>{
            Department.findAll().then((results) => {
                resolve(results);
            }).catch(() => {
                reject("no results returned");
            });
        })
    }

    addEmployee(employeeData){
        return new Promise((resolve,reject)=>{
            Employee.create({
                firstName: employeeData.firstName, 
                last_Name: employeeData.last_Name,
                email: employeeData.email,
                SSN: employeeData.SSN,
                addressStreet: employeeData.addressStreet,
                addressCity: employeeData.addressCity,
                addressState: employeeData.addressState,
                addressPostal: employeeData.addressPostal,
                maritalStatus: employeeData.maritalStatus,
                isManager: (employeeData.isManager) ? true : false,
                employeeManagerNum: employeeData.employeeManagerNum ? employeeData.employeeManagerNum : null,
                status: employeeData.status, 
                department: employeeData.department,
                hireDate: employeeData.hireDate
            }).then((results) => {
                resolve(results)
            }).catch(()=>{
                reject("unable to create employee");
            })
        })
    }

    updateEmployee(employeeData) {
        return new Promise((resolve,reject)=>{ 
            Employee.update({
                firstName: employeeData.firstName, 
                last_Name: employeeData.last_Name,
                email: employeeData.email,
                SSN: employeeData.SSN,
                addressStreet: employeeData.addressStreet,
                addressCity: employeeData.addressCity,
                addressState: employeeData.addressState,
                addressPostal: employeeData.addressPostal,
                maritalStatus: employeeData.maritalStatus,
                isManager: (employeeData.isManager) ? true : false,
                employeeManagerNum: employeeData.employeeManagerNum ? employeeData.employeeManagerNum : null,
                status: employeeData.status, 
                department: employeeData.department,
                hireDate: employeeData.hireDate
            },{
                where: {
                    employeeNum: employeeData.employeeNum,
                }
            }).then((results) => {
                resolve(results);
            }).catch((err)=>{
                reject("unable to create employee" + err);
            });
        })
    }

    deleteEmployeeByNum(empNum){
        return new Promise((resolve,reject)=>{ 
            Employee.destroy({
                where: {
                    employeeNum: empNum,
                }
            }).then((results) => {
                resolve(results);
            }).catch((err)=>{
                reject("unable to delete" + err);
            });
        })
    }

    addDepartment(departmentData){
        return new Promise((resolve,reject)=>{
            Department.create({
                departmentName: departmentData.departmentName ? departmentData.departmentName:null,
            }).then((results) => {
                resolve(results)
            }).catch(()=>{
                reject("unable to create department");
            })
        })  
    }

    updateDepartment(departmentData){

        return new Promise((resolve,reject)=>{ 
            Department.update({
                departmentName: departmentData.departmentName ? departmentData.departmentName:null,
            },{
                where: {
                    departmentId: departmentData.departmentId,
                }
            }).then((results) => {
                resolve(results);
            }).catch(()=>{
                reject("unable to create department");
            });
        })
    }

    getDepartmentById(id){
        return new Promise((resolve,reject)=>{ 
            Department.findOne({
                where:{
                    departmentId: id,
                }
            })
            .then((results)=>{
                resolve(results);
            }).catch(()=>{
                reject("no results returned");
            })
        })
    }

    
}

module.exports = new DataService;