/*********************************************************************************
*		WEB322	– Assignment	04
*		I	declare	that	this	assignment	is	my	own	work	in	accordance	with	Seneca		Academic	Policy.		No	part	
*		of	this	assignment	has	been	copied	manually	or	electronically	from	any	other	source	
*		(including	3rd	party	web	sites)	or	distributed	to	other	students.
*	
*		Name:	David Yu Hang Lin	Student	ID:	135034163	Date:	October 16, 2017
*
*		Online	(Heroku)	Link:	https://obscure-depths-27471.herokuapp.com/
*
********************************************************************************/	

var express = require('express');
var path = require('path');
var http = require('http');
var ds = require('./data-service');
const exphbs = require('express-handlebars');
const bodyParser = require('body-parser');
var app = express();

app.use(express.static('public'));
app.use(bodyParser.urlencoded({ extended: true }));

app.engine(".hbs", exphbs({
    extname: ".hbs",
    defaultLayout: 'layout',
    helpers:{
        equal: function (lvalue, rvalue, options) {
            if (arguments.length < 3) 
                throw new Error("Handlebars Helper equal needs 2 parameters");
            
            if (lvalue != rvalue) {
                return options.inverse(this);
            } else {
                return options.fn(this);
            }
        }
    }
}));
app.set("view engine", ".hbs");


app.get('/', function (req, res) {
    //res.sendFile(__dirname+'/views/home.hbs')
    res.render("home");
    })

app.get('/about', function (req, res) {
    //res.sendFile(__dirname+'/views/about.hbs')
    res.render("about");
})


app.get('/employees', function (req, res) {


    if (req.query.status) {
        ds.getEmployeesByStatus(req.query.status).then((result)=>{
            res.setHeader("Content-type","text/html");
            res.render("employeeList", {data: result, title:"Employees" });
        }).catch((err)=>res.render("employeeList", {data:{}, title: "Employees" }));
    } 
    else if (req.query.department) {
        ds.getEmployeesByDepartment(req.query.department).then((result)=>{
            res.setHeader("Content-type","text/html");
            res.render("employeeList", {data: result, title:"Employees" });
        }).catch((err)=>response.json({message: err}));
    }
    else if (req.query.manager) {
        ds.getEmployeesByManager(req.query.manager).then((result)=>{
            var manStatus = JSON.parse(JSON.stringify(result));
            res.setHeader("Content-type","text/html");
            res.render("employeeList", {data: manStatus, title:"Employees" });
        }).catch((err)=>response.json({message: err}));
    }else{
        ds.getAllEmployees().then((result)=>{
            var jsonStr = JSON.parse(JSON.stringify(result));
            res.setHeader("Content-type", "text/html");
            res.render("employeeList", {data: jsonStr, title:"Employees" });
        }).catch((err)=>response.render("employeeList", { data: {}, title: "Employees" }));
    }
})

app.get('/employee/:value', function (req, res) {
    // initialize an empty object to store the values
    let viewData = {};

    dataService.getEmployeeByNum(req.params.empNum)
        .then((data) => {
            viewData.data = data; //store employee data in the "viewData" object as "data"
        }).catch(()=>{
            viewData.data = null; // set employee to null if there was an error
        }).then(dataService.getDepartments)
        .then((data) => {
        viewData.departments = data; // store department data in the "viewData" object as "departments"

        // loop through viewData.departments and once we have found the departmentId that matches
        // the employee's "department" value, add a "selected" property to the matching
        // viewData.departments object
        for (let i = 0; i < viewData.departments.length; i++) {
            if (viewData.departments[i].departmentId == viewData.data.department) {
                viewData.departments[i].selected = true;
            }
            }
            }).catch(()=>{
                viewData.departments=[]; // set departments to empty if there was an error
            }).then(()=>{
                if(viewData.data == null){ // if no employee - return an error
                res.status(404).send("Employee Not Found");
            }else{
                res.render("employee", { viewData: viewData }); // render the "employee" view
            }
        });
})

app.get('/employee/delete/:value', (req,res) => {
    ds.deleteEmployeeByNum(req.params.value).then(()=>{
        res.redirect("/employees");
    })
    .catch(()=>{
        res.status(500).send("Unable to Remove Employee / Employee not found)");
    })
})

app.get("/employees/add", (req,res) => {
    ds.getDepartments().then((data)=>{
        res.render("addEmployee", {departments: data});
    })
    .catch(()=>response.render("addEmployee", {departments: []})
    )
})

app.post("/employees/add", (req, res) => {
    ds.addEmployee(req.body)
    .then(()=> res.redirect("/employees"))
    .catch((err)=> console.log(err))
});
app.post("/employee/update", (req, res) => {
    ds.updateEmployee(req.body)
    .then((result)=>{{
        res.redirect("/employees");
    }})
});
   

app.get('/managers', function (req, res) {

    ds.getManagers().then((result)=>{
        res.setHeader("Content-type","text/html")
        res.render("employeeList", { data: result, title: "Employees (Managers)" });
    }).catch((err)=>res.render("employeeList", { data: {}, title: "Employees (Managers)" }))
});

app.get('/departments', function(request, response){
    ds.getDepartments().then((result)=>{
        response.set('Content-Type','text/html; charset=utf-8');
        response.render("departmentList", { data: result, title: "Departments" })
    })
    .catch((err) => response.render("departmentList", { data: {}, title: "Departments" }));
})

app.get('/departments/add', (req,res) => {
    res.render("addDepartment");
})

app.get('/department/:departmentId', function(request, response){
    ds.getDepartmentById(request.params.departmentId).then((result) => {
        response.set('Content-Type','text/html; charset=utf-8');
        response.render("department", { data: result });
    })
    .catch((err) => response.status(404).send("Department Not Found"));  
})

app.post("/departments/add", (req, res) => {
    ds.addDepartment(req.body)
    .then(()=> res.redirect("/departments"))
    .catch((err)=> console.log(err));
});

app.post("/departments/update", (req, res) => {
    ds.updateDepartment(req.body)
    .then((result)=>{
        res.redirect("/departments")
    })
    .catch((err)=> console.log(err));
    
});

app.get('*', function(req,res) {
    res.status(404).send("Page Not Found");
})

ds.initialize().then((result)=>{})
.then(() => {
    var server = app.listen(process.env.PORT || 8080, function() {
        var host = server.address().address
        var port = server.address().port

        console.log("Express http server listening on %s", port)
    });
}).catch((err)=>console.log("Cannot start server: "+ err));
